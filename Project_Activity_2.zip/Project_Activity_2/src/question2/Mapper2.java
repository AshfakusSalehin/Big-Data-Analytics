package question2;
/*********************
 * @Title: The day was hot or cold: Mapper class
 * 
 * @Description:This class gets the date and average temperature. Then it analysis the data and decides whether id hot or cold  and send it to reducer
 * @Copyright: MD.ASHFAK US SALEHIN@2021
 * 
 * @Author: MD.ASHFAK US SALEHIN 
 * 
 * @version 1
 */
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class Mapper2 extends Mapper<LongWritable, Text, Text, Text>{

	public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException
{
String line = value.toString().trim();
if(!(line.length()==0)){
String date =line.substring(6,14).trim();
double temp = Double.parseDouble(line.substring(63,69).trim());

  if(temp>35){
	  Text text = new Text(date+" was a hot day with temperature :");
	  Text dtemp= new Text(String.valueOf(temp));
	  con.write(text, dtemp);
  }
  
  if(temp<10){
	  Text text = new Text(date+" was a cold day with temperature :");
	  Text dtemp= new Text(String.valueOf(temp));
	  con.write(text, dtemp);
  }}
}
}
