package question2;

import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
/*********************
 * @Title: The day was hot or cold: Reducer class
 * 
 * @Description:This class gets the date and average temperature from mapper and forwards it
 * @Copyright: MD.ASHFAK US SALEHIN@2021
 * 
 * @Author: MD.ASHFAK US SALEHIN 
 * 
 * @version 1
 */
    
public class Reducer2 extends Reducer<Text,Text, Text, Text>
{	
public void reduce(Text word, Text values, Context con) throws IOException, InterruptedException
{
	
   con.write(word, values);
   
}
}