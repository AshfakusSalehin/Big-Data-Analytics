package question1;
/*********************
 * @Title: Highest temperature for each year: Mapper class
 * 
 * @Description:This class gets the date and average temperature and forwards them to reducer.
 * 
 * @Copyright: MD.ASHFAK US SALEHIN@2021
 * 
 * @Author: MD.ASHFAK US SALEHIN 
 * 
 * @version: 1
 */
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class Mapper1 extends Mapper<LongWritable, Text, Text, Text>{

	public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException
{
String line = value.toString();
if(!(line.length()==0)){

String year =line.substring(6,10).trim();
  Text outputKey = new Text(year);
  String temp= line.substring(63,69).trim();
  float tempt = Float.parseFloat(temp);
  if (tempt>35){
 
  con.write(outputKey, new Text(temp));
  }
  }}
}

