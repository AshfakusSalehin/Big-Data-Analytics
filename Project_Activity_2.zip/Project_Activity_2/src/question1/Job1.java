/*********************
 * @Title: Highest temperature for each year : Job class
 * 
 * @Description:This class allows the user to configure the job, submit it, control its execution and query the state.
 * 
 * @Copyright: MD.ASHFAK US SALEHIN@2021
 * 
 * @Author: MD.ASHFAK US SALEHIN 
 * 
 * @version 1
 */
package question1;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class Job1 {
	     
	public static void main(String [] args) throws Exception
	{
		Configuration c=new Configuration();
		String[] files=new GenericOptionsParser(c,args).getRemainingArgs();
		Path input=new Path(files[0]);
		Path output=new Path(files[1]);
		Job j=new Job(c,"Tempcount");
		j.setJarByClass(Job1.class);
		j.setOutputKeyClass(Text.class);
		j.setOutputValueClass(Text.class);
		j.setMapperClass(Mapper1.class);
		j.setReducerClass(Reducer1.class);
		j.setInputFormatClass(TextInputFormat.class);
		j.setOutputFormatClass(TextOutputFormat.class);

		FileInputFormat.addInputPath(j, input);
		FileOutputFormat.setOutputPath(j, output);
		
		output.getFileSystem(c).delete(output);
		System.exit(j.waitForCompletion(true)?0:1);
	} 
}
