package question1;
/*********************
 * @Title: Highest temperature for each year: Reducer class
 * 
 * @Description:This class gets the date and average temperature and filters out the highest among them.
 * 
 * @Copyright: MD.ASHFAK US SALEHIN@2021
 * 
 * @Author: MD.ASHFAK US SALEHIN 
 * 
 * @version: 1
 */
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

    
public class Reducer1 extends Reducer<Text, Text,Text,Text>
{
public void reduce(Text word, Iterable<Text> values, Context con) throws IOException, InterruptedException
{
	
//String max = "0";
float max=0;
 for(Text value : values)
   {
	 String str = value.toString();
	 Float f = Float.parseFloat(str);
   if(f>max){
	   max=f;
   }
   }
  Text text = new Text("Highest Temperature of "+word+" was :");
  con.write(text, new Text(String.valueOf(max)));
}


}
