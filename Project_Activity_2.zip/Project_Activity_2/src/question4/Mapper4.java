package question4;
/*********************
 * @Title: Maximum and minimum temperature of each day: Mapper class
 * 
 * @Description:This class gets the date, maximum and minimum temperature. Then it analysis the data and sends the data to reducer
 * 
 * @Copyright: MD.ASHFAK US SALEHIN@2021
 * 
 * @Author: MD.ASHFAK US SALEHIN 
 * 
 * @version 1
 */
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class Mapper4 extends Mapper<LongWritable, Text, Text, Text>{

	public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException
{
		String line = value.toString();
		if(!(line.length()==0)){
		String date =line.substring(6,14);
		double coldtemp = Double.parseDouble(line.substring(47,53).trim());
		double hottemp = Double.parseDouble(line.substring(39,45).trim());


		 
			  Text text1 = new Text(date+" had a maximum temperature of :"+String.valueOf(hottemp));
			  Text text2 = new Text(" and a minimum temperature of :"+String.valueOf(coldtemp));
			  con.write(text1, text2);			
			  		  

		}


		}
}


