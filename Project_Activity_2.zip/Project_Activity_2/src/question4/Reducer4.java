package question4;
/*********************
 * @Title: Maximum and minimum temperature of each day: Reducer class
 * 
 * @Description:This class gets the analyzed data from mapper and forwards it
 * @Copyright: MD.ASHFAK US SALEHIN@2021
 * 
 * @Author: MD.ASHFAK US SALEHIN 
 * 
 * @version 1
 */
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

  
public class Reducer4 extends Reducer<Text, Text, Text, Text>
{
	 

public void reduce(Text word, Text values, Context con) throws IOException, InterruptedException
{
  con.write(word, values); 
}
}