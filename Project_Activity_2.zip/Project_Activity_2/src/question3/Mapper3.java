package question3;
/*********************
 * @Title: top 10 hottest and coldest day 
 * 
 * @Description:This class gets the date, maximum and minimum temperature. Then it analysis the data and sends top 10 hottest
 * and coldest day data to reducer
 * 
 * @Copyright: MD.ASHFAK US SALEHIN@2021
 * 
 * @Author: MD.ASHFAK US SALEHIN 
 * 
 * @version 1
 */
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class Mapper3 extends Mapper<LongWritable, Text, Text, Text>
{
	private TreeMap<Text, Text> hotmap, coldmap;
	@Override  
    public void setup(Context context) throws IOException,         InterruptedException
    {
        hotmap = new TreeMap<Text, Text> ();
        coldmap = new TreeMap<Text, Text> ();
    }
public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException
{
String line = value.toString();
if(!(line.length()==0)){
String date =line.substring(6,14);
double coldtemp = Double.parseDouble(line.substring(47,53).trim());
double hottemp = Double.parseDouble(line.substring(39,45).trim());

  if(hottemp>35){
	  Text text = new Text(date+" Has the top hottest temp of ");
	  hotmap.put(text, new Text(String.valueOf(hottemp)));
	  if(hotmap.size()>10)
	  {hotmap.remove(hotmap.firstKey());}
	  //con.write(text, new Text(String.valueOf(hottemp)));
	
  }
  
  if(coldtemp<10){
	  Text text = new Text(date+" Has the top coldest temp of ");
	  coldmap.put(text, new Text(String.valueOf(coldtemp)));
	  if(coldmap.size()>10)
	  {coldmap.remove(coldmap.lastKey());}
	  //con.write(text, new Text(String.valueOf(coldtemp)));
  }
}
}
	@Override
	public void cleanup(Context context) throws IOException,   InterruptedException
	{
   	 for (Map.Entry<Text, Text> entry : hotmap.entrySet()) 
	    	    {

    	       Text words = entry.getKey();
    	        Text count = entry.getValue(); 
	        	context.write(words, count);    
	    	    }
    	 for (Map.Entry<Text, Text> entry : coldmap.entrySet()) 
 	    {

	       Text words = entry.getKey();
	        Text count = entry.getValue(); 
     	context.write(words, count);    
 }}
}