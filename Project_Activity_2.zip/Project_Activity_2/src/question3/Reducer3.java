package question3;
/*********************
 * @Title: Top 10 hottest and coldest day: Reducer class
 * 
 * @Description:This class gets the analyzed data from mapper and forwards it
 * @Copyright: MD.ASHFAK US SALEHIN@2021
 * 
 * @Author: MD.ASHFAK US SALEHIN 
 * 
 * @version 1
 */
    
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;


//import javax.swing.text.html.HTMLDocument.Iterator;

    
public class Reducer3 extends Reducer<Text, Text, Text, Text>
{
	 

public void reduce(Text word, Text values, Context con) throws IOException, InterruptedException
{
	
	
  con.write(word, values);
  
}



}
